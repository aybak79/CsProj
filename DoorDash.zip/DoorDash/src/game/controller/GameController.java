package game.controller;

import game.Main;
import game.engine.Board;
import game.engine.Constants;
import game.engine.Game;
import game.engine.Role;
import game.engine.TurnResult;
import game.engine.monsters.Dasher;
import game.engine.monsters.Monster;
import game.engine.monsters.MultiTasker;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import game.engine.cards.Card;
import game.engine.exceptions.InvalidMoveException;
import game.engine.exceptions.InvalidTurnException;
import game.engine.exceptions.OutOfEnergyException;
import javafx.scene.image.Image;
import static javafx.geometry.Pos.*;
import game.engine.cells.*;
import javafx.animation.*;
import javafx.util.Duration;

public class GameController {
    static Game game;
    @FXML private Button playerRollButton;
    @FXML private Button playerActivateButton;
    @FXML private Button opponentRollButton;
    @FXML private Button opponentActivateButton;
    @FXML private Label opponentConfusionTurns;
    @FXML private Label playerConfusionTurns;
    @FXML private TextField playerORole;
    @FXML private TextField playerCRole;
    @FXML private TextField playerType;
    @FXML private TextField playerName;
    @FXML private TextField playerEnergy;
    @FXML private TextField opponentORole;
    @FXML private TextField opponentCRole;
    @FXML private TextField opponentType;
    @FXML private TextField opponentName;
    @FXML private TextField opponentEnergy;
    @FXML private ImageView player;
    @FXML private ImageView opponent;
    @FXML private ImageView dice;
    @FXML private GridPane board;
    @FXML private ImageView playerShield;
    @FXML private ImageView playerFreeze;
    @FXML private ImageView playerConfusion;
    @FXML private Label playerPower;
    @FXML private ImageView opponentShield;
    @FXML private ImageView opponentFreeze;
    @FXML private ImageView opponentConfusion;
    @FXML private Label opponentPower;
    @FXML private ImageView playerSelector;
    @FXML private ImageView opponentSelector;
    @FXML private Label cardsCount;
    @FXML private Label cardTitle;
    @FXML private Label cardEffect;
    @FXML private VBox cardPanel;
    @FXML private Label cardType;
    @FXML private Pane main;
    @FXML private Pane errorOverlay;
    @FXML private Label errorMessage;
    @FXML private Button closeErrorButton;
    @FXML private Label errorMessageTitle;
    @FXML private Pane root;
    private double width;
    private double height;

    private static final Image IMG_SULLIVAN = new Image(GameController.class.getResourceAsStream("/game/view/assets/Sullivan.png"));
    private static final Image IMG_WAZOWSKI = new Image(GameController.class.getResourceAsStream("/game/view/assets/Wazowski.png"));
    private static final Image IMG_RANDALL  = new Image(GameController.class.getResourceAsStream("/game/view/assets/Randall.png"));
    private static final Image IMG_CELIA    = new Image(GameController.class.getResourceAsStream("/game/view/assets/Celia.png"));
    private static final Image IMG_ROZ      = new Image(GameController.class.getResourceAsStream("/game/view/assets/Roz.png"));
    private static final Image IMG_FUNGUS   = new Image(GameController.class.getResourceAsStream("/game/view/assets/Fungus.png"));
    private static final Image IMG_WATERNOOSE = new Image(GameController.class.getResourceAsStream("/game/view/assets/Waternoose.png"));
    private static final Image IMG_YETI     = new Image(GameController.class.getResourceAsStream("/game/view/assets/Yeti.png"));
    private int prevPlayerEnergy;
    private int prevOpponentEnergy;
    @FXML
    public void initialize() {
        main.requestFocus();
        root.getStyleClass().clear();
        root.getStyleClass().add(Main.preferedTheme);
        errorOverlay.setVisible(false);
        Rectangle2D screen = Screen.getPrimary().getBounds();
        width = screen.getWidth();
        height = screen.getHeight();
        root.setPrefWidth(width);
        root.setPrefHeight(height);
        layoutAll();
        playerORole.setText(game.getPlayer().getOriginalRole().toString());
        playerType.setText(game.getPlayer().getClass().getSimpleName());
        playerName.setText(game.getPlayer().getName());
        opponentORole.setText(game.getOpponent().getOriginalRole().toString());
        opponentType.setText(game.getOpponent().getClass().getSimpleName());
        opponentName.setText(game.getOpponent().getName());
        initMonsterCells();
        initDoorCells();
        updateUI(new TurnResult(0, null, false, false));
        prevPlayerEnergy = game.getPlayer().getEnergy();
        prevOpponentEnergy = game.getOpponent().getEnergy();
    }
    private void layoutAll() {
        main.setLayoutX(x(0.1143));
        main.setLayoutY(y(0.097));
        errorOverlay.setLayoutX(x(0.3775));
        errorOverlay.setLayoutY(y(0.3768));
    }
    
    private double x(double percentX) { 
        return width * percentX; 
    }

    private double y(double percentY) { 
        return height * percentY; 
    }

    private void updateUI(TurnResult turnResult) {
        playerCRole.setText(game.getPlayer().getRole().toString());
        playerEnergy.setText(String.valueOf(game.getPlayer().getEnergy()));
        opponentCRole.setText(game.getOpponent().getRole().toString());
        opponentEnergy.setText(String.valueOf(game.getOpponent().getEnergy()));
        if (turnResult.roll > 0) {
            dice.setImage(new Image(getClass().getResourceAsStream("/game/view/assets/" + turnResult.roll + ".png")));
        }
        playerSelector.setVisible(game.getPlayer() == game.getCurrent());
        opponentSelector.setVisible(game.getOpponent() == game.getCurrent());
        playerShield.setVisible(game.getPlayer().isShielded());
        playerFreeze.setVisible(game.getPlayer().isFrozen());
        playerConfusion.setVisible(game.getPlayer().isConfused());
        playerConfusionTurns.setVisible(playerConfusion.isVisible());
        playerConfusionTurns.setText("" + game.getPlayer().getConfusionTurns());
        if(game.getPlayer() instanceof MultiTasker) {
            playerPower.setText("Powered Up Turns: " + ((MultiTasker)game.getPlayer()).getNormalSpeedTurns());
        } else if(game.getPlayer() instanceof Dasher) {
            playerPower.setText("Powered Up Turns: " + ((Dasher)game.getPlayer()).getMomentumTurns());
        } else playerPower.setText("Powered Up Turns: " + 0);
        opponentShield.setVisible(game.getOpponent().isShielded());
        opponentFreeze.setVisible(game.getOpponent().isFrozen());
        opponentConfusion.setVisible(game.getOpponent().isConfused());
        opponentConfusionTurns.setVisible(opponentConfusion.isVisible());
        opponentConfusionTurns.setText("" + game.getOpponent().getConfusionTurns());
        if(game.getOpponent() instanceof MultiTasker) {
            opponentPower.setText("Powered Up Turns: " + ((MultiTasker)game.getOpponent()).getNormalSpeedTurns());
        } else if(game.getOpponent() instanceof Dasher) {
            opponentPower.setText("Powered Up Turns: " + ((Dasher)game.getOpponent()).getMomentumTurns());
        } else opponentPower.setText("Powered Up Turns: " + 0);

        if (game.getWinner() != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/game/view/views/GameOverView.fxml"));
                Scene scene = new Scene(loader.load());
                Stage stage = (Stage) main.getScene().getWindow();
                stage.setTitle("Game Over");
                stage.setScene(scene);
                stage.setFullScreen(true);
                stage.setFullScreenExitHint("");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        updateBoardImages(board);

        if(turnResult.landedOnDoor) {
            ImageView person = (game.getCurrent() == game.getPlayer()) ? opponent : player;
            Monster playableCharacter = (game.getCurrent() == game.getPlayer()) ? game.getOpponent() : game.getPlayer();
            int[] pos = intToCoords(playableCharacter.getPosition());
            StackPane cell = (StackPane) getCell(pos[0], pos[1]);
            for(Node n :  cell.getChildren()) {
                if(n instanceof ImageView && n != person && playableCharacter.getPosition() != 99) {
                    if(((ImageView) n).getImage().getUrl().contains("other")) ((ImageView) n).setImage(new Image(getClass().getResourceAsStream("/game/view/assets/other-door-closed.png")));
                    else ((ImageView) n).setImage(new Image(getClass().getResourceAsStream("/game/view/assets/door-closed.png")));
                }
            }
        }

        cardsCount.setText("Cards: " + Board.getCards().size());
        if (!Board.getDrawnCards().isEmpty()) {
            Card last = Board.getDrawnCards().getFirst();
            cardTitle.setText(last.getName());
            cardType.setText(last.getClass().getSimpleName().replace("Card", ""));
            cardEffect.setText(last.getDescription());
        }

        if (playerRollButton.getScene() != null) {
            showEnergyChange(game.getPlayer(), prevPlayerEnergy);
            showEnergyChange(game.getOpponent(), prevOpponentEnergy);
        }
        prevPlayerEnergy = game.getPlayer().getEnergy();
        prevOpponentEnergy = game.getOpponent().getEnergy();
    }

    private void updateBoardImages(GridPane board) {
        if (player.getParent() != null) ((Pane) player.getParent()).getChildren().remove(player);
        int[] playerPos = intToCoords(game.getPlayer().getPosition() % 100);
        StackPane playerCell = (StackPane) getCell(playerPos[0], playerPos[1]);
        playerCell.getChildren().add(player);
        if (opponent.getParent() != null) ((Pane) opponent.getParent()).getChildren().remove(opponent);
        int[] opponentPos = intToCoords(game.getOpponent().getPosition() % 100);
        StackPane opponentCell = (StackPane) getCell(opponentPos[0], opponentPos[1]);
        opponentCell.getChildren().add(opponent);
    }

    private Node getCell(int row, int col) {
        for (Node node : board.getChildren()) {
            int r = GridPane.getRowIndex(node) == null ? 0 : GridPane.getRowIndex(node);
            int c = GridPane.getColumnIndex(node) == null ? 0 : GridPane.getColumnIndex(node);
            if (r == row && c == col)
                return node;
        }
        return null;
    }

    private int[] intToCoords(int pos) {
        int row = pos / 10;
        int gridRow = 9 - row;
        int gridCol;
        if (row % 2 == 0) {
            gridCol = pos % 10;
        } else {
            gridCol = 9 - (pos % 10);
        }
        return new int[]{gridRow, gridCol};
    }

    private int coordsToInt(int gridRow, int gridCol) {
        int row = 9 - gridRow;
        int col = (row % 2 == 0) ? gridCol : (9 - gridCol);
        return row * 10 + col;
    }

    private void showEnergyChange(Monster monster, int oldEnergy) {
        int delta = monster.getEnergy() - oldEnergy;
        if (delta == 0) return;

        int[] coords = intToCoords(monster.getPosition());
        StackPane cell = (StackPane) getCell(coords[0], coords[1]);
        if (cell == null) return;

        javafx.geometry.Bounds bounds = cell.localToScene(cell.getBoundsInLocal());

        String sign = delta > 0 ? "+" : "";
        Label indicator = new Label(sign + delta);
        indicator.setStyle(
            "-fx-font-size: 16px; -fx-font-weight: bold; " +
            "-fx-text-fill: " + (delta > 0 ? "#00ff88" : "#ff4444") + "; " +
            "-fx-background-color: rgba(0,0,0,0.75); " +
            "-fx-padding: 4 8 4 8; -fx-background-radius: 8;"
        );

        indicator.setLayoutX(bounds.getMinX() + bounds.getWidth() / 2 - 20);
        indicator.setLayoutY(bounds.getMinY() - 20);

        Pane root = (Pane) main.getScene().getRoot();
        root.getChildren().add(indicator);

        FadeTransition ft = new FadeTransition(Duration.seconds(3.0), indicator);
        ft.setFromValue(1.0);
        ft.setToValue(0.0);
        ft.setOnFinished(e -> root.getChildren().remove(indicator));
        ft.play();
    }

    private void initMonsterCells() {
        for(int i = 0; i < Constants.MONSTER_CELL_INDICES.length; i++) {
            int[] cords = intToCoords(Constants.MONSTER_CELL_INDICES[i]);
            StackPane cell = (StackPane) getCell(cords[0], cords[1]);
            Monster m = Board.getStationedMonsters().get(i);
            Image img = switch (m.getName()) {
                case "James P. Sullivan"   -> IMG_SULLIVAN;
                case "Mike Wazowski"       -> IMG_WAZOWSKI;
                case "Randall Boggs"       -> IMG_RANDALL;
                case "Celia Mae"           -> IMG_CELIA;
                case "Roz"                 -> IMG_ROZ;
                case "Fungus"              -> IMG_FUNGUS;
                case "Henry J. Waternoose" -> IMG_WATERNOOSE;
                case "Yeti"                -> IMG_YETI;
                default                    -> null;
            };
            if (img != null) {
                ImageView iv = new ImageView(img);
                iv.setFitWidth(40);
                iv.setFitHeight(55);
                iv.setPreserveRatio(true);
                StackPane.setAlignment(iv, CENTER);
                cell.getChildren().add(iv);
            }
            Label nameLabel = new Label(m.getName());
                nameLabel.setStyle(
                    "-fx-font-size: 9px; -fx-text-fill: white; " +
                    "-fx-background-color: rgba(0,0,0,0.6); " +
                    "-fx-padding: 2 4 2 4; -fx-background-radius: 4;"
            );
            StackPane.setAlignment(nameLabel, BOTTOM_CENTER);
            cell.getChildren().add(nameLabel);
            cell.getStyleClass().clear();
            cell.getStyleClass().add(m.getRole() == Role.LAUGHER ? "laugher-monster" : "scarer-monster");
        }
    }

    private void initDoorCells() {
        for (Node node : board.getChildren()) {
            if (node instanceof StackPane cell) {
                int row = GridPane.getRowIndex(node) == null ? 0 : GridPane.getRowIndex(node);
                int col = GridPane.getColumnIndex(node) == null ? 0 : GridPane.getColumnIndex(node);
                int pos = coordsToInt(row, col);

                int boardRow = pos / 10;
                int boardCol = (boardRow % 2 == 0) ? pos % 10 : 9 - (pos % 10);
                Cell boardCell = game.getBoard().getBoardCells()[boardRow][boardCol];

                if (boardCell instanceof DoorCell door) {
                    Label energyLabel = new Label("" + door.getEnergy());
                    energyLabel.setStyle(
                        "-fx-font-size: 10px; -fx-font-weight: bold; -fx-text-fill: " +
                        (door.getEnergy() > 0 ? "white" : "red") + "; " +
                        "-fx-background-color: rgba(0,0,0,0.6); " +
                        "-fx-padding: 2 4 2 4; -fx-background-radius: 4;"
                    );
                    StackPane.setAlignment(energyLabel, BOTTOM_RIGHT);
                    cell.getChildren().add(energyLabel);
                }
            }
        }
    }

    private void showError(String message, String title) {
        errorMessage.setText(message);
        errorMessageTitle.setText(title);
        errorOverlay.setVisible(true);
        errorOverlay.toFront();
        main.setDisable(true);
    }

    @FXML
    private void handleCloseError() {
        errorOverlay.setVisible(false);
        main.setDisable(false);
    }
    
   @FXML
    private void handlePlayerPowerup(ActionEvent event) throws Exception {
        try {
            if (game.getCurrent() != game.getPlayer()) {
                throw new InvalidTurnException();
            }
            game.usePowerup();
            updateUI(new TurnResult(0, null, false, false));
            playerActivateButton.setDisable(true);
        } catch (OutOfEnergyException e) {
            showError(e.getMessage(), "Out Of Energy!");
        } catch (InvalidTurnException e) {
            showError("It's not your turn!", "Invalid Turn");
        }
    }

    @FXML
    private void handleOpponentPowerup(ActionEvent event) throws Exception {
        try {
            if (game.getCurrent() != game.getOpponent()) {
                throw new InvalidTurnException();
            }
            game.usePowerup();
            updateUI(new TurnResult(0, null, false, false));
            opponentActivateButton.setDisable(true);
        } catch (OutOfEnergyException e) {
            showError(e.getMessage(), "Out Of Energy");
        } catch (InvalidTurnException e) {
            showError("It's not your turn!", "Invalid Turn");
        }
    }

    @FXML
    private void handlePlayerRoll(ActionEvent event) throws Exception {
        try {
            if (game.getCurrent() != game.getPlayer()) {
                throw new InvalidTurnException();
            }
            TurnResult turnResult = game.playTurn();
            updateUI(turnResult);
            playerActivateButton.setDisable(false);
        } catch (InvalidMoveException e) {
            showError(e.getMessage(), "Invalid Move");
        } catch (InvalidTurnException e) {
            showError("It's not your turn!", "Invalid Turn");
        }
    }

    @FXML
    private void handleOpponentRoll(ActionEvent event) throws Exception {
        try {
            if (game.getCurrent() != game.getOpponent()) {
                throw new InvalidTurnException();
            }
            TurnResult turnResult = game.playTurn();
            updateUI(turnResult);
            opponentActivateButton.setDisable(false);
        } catch (InvalidMoveException e) {
            showError(e.getMessage(), "Invalid Move");
        } catch (InvalidTurnException e) {
            showError("It's not your turn!", "Invalid Turn");
        }
    }

    @FXML
    private void handleKeyPress(KeyEvent event) {
        KeyCode key = event.getCode();
        switch (key) {
            case E:
                game.getCurrent().setEnergy(game.getCurrent().getEnergy() + 100);
                updateUI(new TurnResult(0, null, false, false));
                break;
            case W:
                game.getCurrent().setPosition(99);
                updateUI(new TurnResult(0, null, false, false));
                break;
            default:
                break;
        }
    }
}